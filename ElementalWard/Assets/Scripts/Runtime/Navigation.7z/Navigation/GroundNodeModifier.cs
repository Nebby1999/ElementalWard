using UnityEngine;

namespace ElementalWard.Navigation
{
    public class GroundNodeModifier : MonoBehaviour
    {
        public bool isObstacle;
        public float movementPenalty;
    }
}