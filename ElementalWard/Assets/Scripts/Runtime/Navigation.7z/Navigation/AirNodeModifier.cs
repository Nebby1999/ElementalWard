using UnityEngine;

namespace ElementalWard.Navigation
{
    public class AirNodeModifier : MonoBehaviour
    {
        public bool isWall;
        public float movementPenalty;
    }
}