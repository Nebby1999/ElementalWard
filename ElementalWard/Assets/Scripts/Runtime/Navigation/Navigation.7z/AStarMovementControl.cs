using ElementalWard.Pathfinding;
using KinematicCharacterController;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ElementalWard
{
    [RequireComponent(typeof(CharacterMaster))]
    public class AStarMovementControl : MonoBehaviour
    {
        public NodeGridProvider desiredNodeGrid;
        public CharacterMaster CharacterMaster { get; private set; }

        private Transform target;
        private Vector3[] path = Array.Empty<Vector3>();
        private Vector3 currentWaypoint;
        private float distanceFromCurrentWaypoint;
        private int targetIndex;

        private Vector3 CurrentPos => motor.TransientPosition;
        private CharacterBody body;
        private CharacterInputBank inputBank;
        private ICharacterMovementController characterMovementController;
        private KinematicCharacterMotor motor;
        private CapsuleCollider motorCapsule;
        private bool flying;
        private bool grounded;
        private bool obtainedBodyComponents;

        private void Awake()
        {
            CharacterMaster = GetComponent<CharacterMaster>();
            CharacterMaster.OnBodySpawned += GetBodyComponents;
            PlayableCharacterMaster.OnPlayableBodySpawned += SetTarget;
        }

        private void Update()
        {
            if (!target)
                return;

            if(path.Length == 0)
            {
                PathRequestManager.RequestPath(desiredNodeGrid, transform.position, target.position, OnPathFound);
            }
        }

        private void FixedUpdate()
        {
            if (path.Length == 0 || !obtainedBodyComponents)
                return;

            ProcessPath();
        }

        private void ProcessPath()
        {
            currentWaypoint = path[targetIndex];
            distanceFromCurrentWaypoint = Vector3.Distance(currentWaypoint, CurrentPos);
            if(distanceFromCurrentWaypoint < 0.7f)
            {
                targetIndex++;
                if(targetIndex >= path.Length - 1)
                {
                    targetIndex = path.Length - 1;
                }
                return;
            }

            var vector = currentWaypoint - CurrentPos;
            var movementDirection = vector.normalized;
            if(inputBank)
            {
                inputBank.moveVector = movementDirection;
                inputBank.LookRotation = Quaternion.LookRotation(movementDirection, motor.CharacterUp);
            }
        }

        private void OnPathFound(Vector3[] path, bool success)
        {
            if (!success)
                return;

            this.path = path;
            targetIndex = 0;
        }

        private void GetBodyComponents(CharacterBody body)
        {
            this.body = body;
            inputBank = body.GetComponent<CharacterInputBank>();
            characterMovementController = body.GetComponent<ICharacterMovementController>();
            if (characterMovementController != null)
            {
                motor = characterMovementController.Motor;
                motorCapsule = characterMovementController.Motor.Capsule;
                flying = characterMovementController is FlyingCharacterMovementController;
                grounded = characterMovementController is GroundedCharacterMovementController;
            }
            obtainedBodyComponents = true;
        }

        private void SetTarget(CharacterBody obj)
        {
            target = obj.transform;
        }

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.yellow;
            if (path.Length > 0)
            {
                for (int i = 0; i < path.Length; i++)
                {
                    Vector3 pos = path[i];
                    Gizmos.DrawWireSphere(pos, 0.5f);
                }
                Gizmos.color = Color.green;
                Gizmos.DrawCube(currentWaypoint, Vector3.one * 0.5f);
                //Debug.DrawLine(CurrentPos, CurrentPos + (_movementDirection * 4), Color.red, 0.1f);
            }
        }
    }
}
