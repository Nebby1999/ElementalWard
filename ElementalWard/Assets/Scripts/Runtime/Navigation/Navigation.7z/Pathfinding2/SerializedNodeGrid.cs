using System;
using System.Collections.Generic;
using UnityEngine;

namespace ElementalWard.Pathfinding2
{
    [CreateAssetMenu(menuName = ElementalWardApplication.APP_NAME + "/SerializedNodeGrid")]
    public class SerializedNodeGrid : ScriptableObject
    {
        public struct BakeParams
        {
            public Vector3 position;
            public float nodeRadius;
            public Vector3 gridWorldSize;
        }
        [Serializable]
        private struct SerializableNodeArray
        {
            [SerializeField]
            public SerializedNode[] nodes;
        }

        public int gridSizeX;
        public int gridSizeY;

        [SerializeField]
        private SerializableNodeArray[] serializedNodes = Array.Empty<SerializableNodeArray>();

        public RuntimeNode[,] RuntimeNodes
        {
            get
            {
                if(_nodes == null)
                {
                    UpdateRuntimeNodes();
                }
                return _nodes;
            }
        }
        private RuntimeNode[,] _nodes;

        public void Bake(BakeParams bakeParams)
        {
            float nodeRadius = bakeParams.nodeRadius;
            Vector2 gridWorldSize = bakeParams.gridWorldSize;
            Vector3 position = bakeParams.position;

            float nodeDiameter = nodeRadius * 2;
            gridSizeX = Mathf.RoundToInt(gridWorldSize.x / nodeDiameter);
            gridSizeY = Mathf.RoundToInt(gridWorldSize.y / nodeDiameter);

            serializedNodes = new SerializableNodeArray[gridSizeX];
            Vector3 worldBottomLeft = position - Vector3.right * gridWorldSize.x / 2 - Vector3.forward * gridWorldSize.y / 2;

            for(int x = 0; x < gridSizeX; x++)
            {
                serializedNodes[x].nodes = new SerializedNode[gridSizeY];
                for(int y = 0; y < gridSizeY; y++)
                {
                    Vector3 worldPoint = worldBottomLeft + Vector3.right * (x * nodeDiameter + nodeRadius) + Vector3.forward * (y * nodeDiameter + nodeRadius);
                    bool open = true;
                    int penalty = 0;

                    bool isValidGround = false;
                    //Check if there's a ceiling.
                    Ray ray = new Ray(worldPoint, Vector3.up);
                    if (Physics.Raycast(ray, out var hit1, 100, LayerIndex.world.Mask))
                    {
                        //If so, raycast from it to find the node's y pos.
                        Vector3 point = hit1.point;

                        ray = new Ray(point, Vector3.down);
                        if (Physics.Raycast(ray, out var hit2, 1024, LayerIndex.world.Mask))
                        {
                            worldPoint.y = hit2.point.y;
                            isValidGround = true;
                        }
                    }
                    else //There's no ceiling, shift by 100 units up and raycast down.
                    {
                        Vector3 point = new Vector3(worldPoint.x, position.y + 100, worldPoint.z);
                        ray = new Ray(point, Vector3.down);
                        if (Physics.Raycast(ray, out var hit2, 1024, LayerIndex.world.Mask))
                        {
                            worldPoint.y = hit2.point.y;
                            isValidGround = true;
                        }
                    }


                    RaycastHit[] hits;
                    ray = new Ray(worldPoint, Vector3.down);
                    hits = Physics.SphereCastAll(ray, nodeRadius, 1024, LayerIndex.world.Mask);
                    foreach (var hit3 in hits)
                    {
                        if (hit3.collider.TryGetComponent<PathfindingModifier>(out var modifier))
                        {
                            open = !modifier.isObstacle;
                            penalty = modifier.penaltyCost;
                            break;
                        }
                    }


                    serializedNodes[x].nodes[y] = new SerializedNode
                    {
                        isValidPosition = isValidGround,
                        isOpen = isValidGround ? open : false,
                        movementPenalty = penalty,
                        worldPosition = worldPoint,
                    };
                }
            }
        }

        public void UpdateRuntimeNodes()
        {
            _nodes = new RuntimeNode[gridSizeX, gridSizeY];
            for(int x = 0; x < gridSizeX; x++)
            {
                for(int y = 0; y < gridSizeY; y++)
                {
                    var serialized = serializedNodes[x].nodes[y];
                    _nodes[x, y] = new RuntimeNode
                    {
                        isOpen = serialized.isOpen,
                        isValidPosition = serialized.isValidPosition,
                        worldPosition = serialized.worldPosition,
                        movementPenalty = serialized.movementPenalty,
                        gridX = x,
                        gridY = y,
                    };
                }
            }
        }
        
    }
}