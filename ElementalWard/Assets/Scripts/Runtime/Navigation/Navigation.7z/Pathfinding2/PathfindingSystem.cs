using JacksonDunstan.NativeCollections;
using KinematicCharacterController;
using Nebula;
using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace ElementalWard.Pathfinding2
{
    public struct RequestPathJob : IJob
    {
        public float3 pathStart;
        public float3 pathEnd;
        public float agentRadius;
        public float agentHeight;
        public AStarNodeGrid.Data nodeGridData;
        public NativeList<float3> results;
        public void Execute()
        {
            bool pathSuccess = false;
            int nodeX;
            int nodeY;

            nodeGridData.GetNodeFromPos(pathStart, out nodeX, out nodeY);
            RuntimeNode startNode = nodeGridData.nodes[nodeX, nodeY];
            nodeGridData.GetNodeFromPos(pathEnd, out nodeX, out nodeY);
            RuntimeNode endNode = nodeGridData.nodes[nodeX, nodeY];

            if(!startNode.isOpen && !endNode.isOpen)
            {
                return;
            }

            NativeHeap<RuntimeNode, RuntimeNode> openSet = new NativeHeap<RuntimeNode, RuntimeNode>();
            NativeHashSet<RuntimeNode> closedSet = new NativeHashSet<RuntimeNode>();

            var heapIndex = openSet.Insert(startNode);
            NativeHeapIndex neighbourIndex = default;

            while(openSet.Count > 0)
            {
                RuntimeNode current = openSet.Pop();
                closedSet.Add(current);
                if(current == endNode)
                {
                    pathSuccess = true;
                    break;
                }

                var neighbouringNodes = nodeGridData.GetNeighbouringNodes(current);
                for(int i = 0; i < neighbouringNodes.Count; i++)
                {
                    RuntimeNode neighbour = neighbouringNodes[i];
                    if (closedSet.Contains(neighbour) || !neighbour.isOpen)
                        continue;

                    int newMovementCostToNeightbour = current.gCost + GetDistance(current, neighbour) + neighbour.movementPenalty;
                    if (newMovementCostToNeightbour < neighbour.gCost || !openSet.IsValidIndex(heapIndex))
                    {
                        neighbour.gCost = newMovementCostToNeightbour;
                        neighbour.hCost = GetDistance(neighbour, endNode);
                        neighbour.parentGridX = current.gridX;
                        neighbour.parentGridY = current.gridY;

                        if (!openSet.IsValidIndex(neighbourIndex))
                            neighbourIndex = openSet.Insert(neighbour);
                    }
                    neighbouringNodes[i] = neighbour;
                }
            }
        }

        public int GetDistance(RuntimeNode from, RuntimeNode to)
        {
            int distanceX = math.abs(from.gridX - to.gridX);
            int distanceY = math.abs(from.gridY - to.gridY);

            if (distanceX > distanceY)
            {
                return 14 * distanceY + 10 * (distanceX - distanceY);
            }
            return 14 * distanceY + 10 * (distanceY - distanceX);
        }
    }
    public class PathfindingSystem : SingletonBehaviour<PathfindingSystem>
    {
        public AStarNodeGrid groundGrid;

        public void RequestPath(AStarNodeGrid grid, Vector3 pathStart, Vector3 pathEnd, float agentRadius, float agentHeight, Action<Vector3[]> onPathFound)
        {
            AStarNodeGrid.Data data = AStarNodeGrid.Data.FromNodeGrid(grid);
            var job = new RequestPathJob()
            {
                pathStart = pathStart,
                pathEnd = pathEnd,
                agentHeight = agentHeight,
                agentRadius = agentRadius,
                nodeGridData = data,
                results = new NativeList<float3>()
            };
            var handle = job.Schedule();
            handle.Complete();

            Vector3[] path = new Vector3[job.results.Length];
            for(int i = 0; i < path.Length; i++)
            {
                path[i] = job.results[i];
            }
            onPathFound(path);

            job.nodeGridData.nodes.Dispose();
            job.results.Dispose();
        }
    }
}