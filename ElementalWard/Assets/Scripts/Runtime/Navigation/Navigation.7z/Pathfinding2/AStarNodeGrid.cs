using JacksonDunstan.NativeCollections;
using System.Collections.Generic;
using System.Xml.Linq;
using Unity.Mathematics;
using UnityEngine;

namespace ElementalWard.Pathfinding2
{
    public class AStarNodeGrid : MonoBehaviour
    {
        public struct Data
        {
            public float2 gridWorldSize;
            public int gridSizeX;
            public int gridSizeY;
            public int maxSize;
            public NativeArray2D<RuntimeNode> nodes;
            public static Data FromNodeGrid(AStarNodeGrid instance)
            {
                Data result = default;
                result.gridWorldSize = instance.gridWorldSize;
                result.gridSizeX = instance.grid.gridSizeX;
                result.gridSizeY = instance.grid.gridSizeY;
                result.maxSize = result.gridSizeX * result.gridSizeY;
                result.nodes = new NativeArray2D<RuntimeNode>(instance.grid.RuntimeNodes, Unity.Collections.Allocator.TempJob);
                return result;
            }

            public void GetNodeFromPos(float3 pos, out int x, out int y)
            {
                float percentX = (pos.x + gridWorldSize.x / 2) / gridWorldSize.x;
                float percentY = (pos.z + gridWorldSize.y / 2) / gridWorldSize.y;

                percentX = math.clamp(percentX, 0, 1);
                percentY = math.clamp(percentY, 0, 1);

                x = (int)math.round((gridSizeX - 1) * percentX);
                y = (int)math.round((gridSizeY - 1) * percentY);

                return;
            }

            public List<RuntimeNode> GetNeighbouringNodes(RuntimeNode node)
            {
                List<RuntimeNode> result = new List<RuntimeNode>();
                for(int x = -1; x <= 1; x++)
                {
                    for(int y = -1; y <= 1; y++)
                    {
                        if (x == 0 && y == 0)
                            continue;

                        int checkX = node.gridX + x;
                        int checkY = node.gridY;

                        if(checkX >= 0 && checkX < gridSizeX && checkY >= 0 && checkY < gridSizeY)
                        {
                            result.Add(nodes[checkX, checkY]);
                        }
                    }
                }
                return result;
            }
        }
        public const float NODE_RADIUS = 0.5f;
        public SerializedNodeGrid grid;
        [SerializeField] private Vector2 gridWorldSize;

        private float nodeDiameter;


        [ContextMenu("Bake To SerializedNodeGrid")]
        public void Bake()
        {
            if (!grid)
                return;

            grid.Bake(new SerializedNodeGrid.BakeParams
            {
                gridWorldSize = gridWorldSize,
                nodeRadius = NODE_RADIUS,
                position = transform.position
            });
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.white;
            Gizmos.DrawWireCube(transform.position, new Vector3(gridWorldSize.x, 1, gridWorldSize.y));
            if (!grid)
                return;

            grid.UpdateRuntimeNodes();
            for (int x = 0; x < grid.gridSizeX; x++)
            {
                for(int y = 0; y < grid.gridSizeY; y++)
                {
                    var node = grid.RuntimeNodes[x,y];

                    if (!node.isValidPosition)
                        continue;
                    Gizmos.color = node.isOpen ? Color.white : Color.black;
                    Gizmos.DrawWireCube(node.worldPosition, 2 * NODE_RADIUS * Vector3.one);
                }
            }
        }
    }
}