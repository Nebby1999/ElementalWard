using ElementalWard.Pathfinding;
using Nebula;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

namespace ElementalWard.Pathfinding2
{
    [Serializable]
    public struct SerializedNode
    {
        public bool isValidPosition;
        public bool isOpen;
        public Vector3 worldPosition;
        public int movementPenalty;
    }

    public struct RuntimeNode : IComparer<RuntimeNode>, IEquatable<RuntimeNode>
    {
        public bool isValidPosition;
        public bool isOpen;
        public float3 worldPosition;
        public int parentGridX;
        public int parentGridY;
        public int movementPenalty;
        public int gCost;
        public int hCost;
        public int FCost => gCost + hCost;

        public int gridX;
        public int gridY;

        public static bool operator ==(RuntimeNode a, RuntimeNode b)
        {
            return a.gridX == b.gridX && a.gridY == b.gridY;
        }

        public static bool operator !=(RuntimeNode a, RuntimeNode b)
        {
            return !(a == b);
        }

        public int CompareTo(RuntimeNode other)
        {
            int compare = FCost.CompareTo(other.FCost);
            if(compare == 0)
            {
                compare = hCost.CompareTo(other.hCost);
            }
            return -compare;
        }

        public bool Equals(RuntimeNode other)
        {
            return this == other;
        }

        public int Compare(RuntimeNode x, RuntimeNode y)
        {
            return x.CompareTo(y);
        }
    }
}