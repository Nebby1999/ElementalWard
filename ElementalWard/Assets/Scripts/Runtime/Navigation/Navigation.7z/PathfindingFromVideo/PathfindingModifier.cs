using UnityEngine;

namespace ElementalWard
{
    public class PathfindingModifier : MonoBehaviour
    {
        public bool isObstacle;
        public int penaltyCost;
    }
}