using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using ElementalWard.Pathfinding;

namespace ElementalWard
{
    public static class PathRequestManager
    {
        private struct PathRequest
        {
            public Vector3 pathStart;
            public Vector3 pathEnd;
            public NodeGridProvider grid;
            public Action<Vector3[], bool> action;
        }

        private static Queue<PathRequest> requests = new Queue<PathRequest>();
        private static PathRequest currentRequest;
        private static bool isProcessingPath;

        public static void RequestPath(NodeGridProvider grid, Vector3 pathStart, Vector3 pathEnd, Action<Vector3[], bool> OnPathFound)
        {
            var request = new PathRequest
            {
                grid = grid,
                pathStart = pathStart,
                pathEnd = pathEnd,
                action = OnPathFound
            };
            requests.Enqueue(request);
            TryProcessNext();
        }

        private static void TryProcessNext()
        {
            if(!isProcessingPath && requests.Count > 0)
            {
                currentRequest = requests.Dequeue();
                isProcessingPath = true;
                PathfindingSystem.StartFindPath(currentRequest.grid, currentRequest.pathStart, currentRequest.pathEnd, FinishedProcessingPath);
            }
        }

        private static void FinishedProcessingPath(Vector3[] path, bool success)
        {
            currentRequest.action(path, success);
            isProcessingPath = false;
            TryProcessNext();
        }
    }
}
