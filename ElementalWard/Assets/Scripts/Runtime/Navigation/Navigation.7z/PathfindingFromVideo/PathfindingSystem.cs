using UnityEngine;
using System.Collections.Generic;
using System.Diagnostics;
using Nebula;
using System.Collections;
using System;
using System.Linq;

namespace ElementalWard.Pathfinding
{
    public class PathfindingSystem
    {
        public static void StartFindPath(NodeGridProvider grid, Vector3 startPos, Vector3 endPos, Action<Vector3[], bool> OnComplete)
        {
            ElementalWardApplication.Instance.StartCoroutine(FindPath(grid, startPos, endPos, OnComplete));
        }

        public static IEnumerator FindPath(NodeGridProvider grid, Vector3 startPos, Vector3 targetPos, Action<Vector3[], bool> OnComplete)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            Vector3[] waypoints = new Vector3[0];
            bool pathSuccess = false;

            Node startNode = grid.GetNodeFromWorldPosition(startPos);
            Node targetNode = grid.GetNodeFromWorldPosition(targetPos);

            if(!startNode.open && !targetNode.open)
            {
                OnComplete(waypoints, pathSuccess);
                yield break;
            }

            Heap<Node> openSet = new Heap<Node>(grid.MaxSize);
            HashSet<Node> closedSet = new HashSet<Node>();

            openSet.Add(startNode);
            while(openSet.Count > 0)
            {
                Node current = openSet.RemoveFirst();
                closedSet.Add(current);
                if(current == targetNode)
                {
                    sw.Stop();
                    UnityEngine.Debug.Log($"Path found in: {sw.ElapsedMilliseconds} ms");
                    pathSuccess = true;
                    break;
                }

                foreach(Node neighbour in grid.GetNeighbouringNodes(current))
                {
                    if (closedSet.Contains(neighbour) || !neighbour.open)
                        continue;

                    int newMovementCostToNeighbour = current.gCost + GetDistance(current, neighbour) + neighbour.movementPenalty;
                    if(newMovementCostToNeighbour < neighbour.gCost || !openSet.Contains(neighbour))
                    {
                        neighbour.gCost = newMovementCostToNeighbour;
                        neighbour.hCost = GetDistance(neighbour, targetNode);
                        neighbour.parent = current;

                        if (!openSet.Contains(neighbour))
                            openSet.Add(neighbour);
                        else
                            openSet.UpdateItem(neighbour);
                    }
                }
            }
            yield return null;
            if(pathSuccess)
            {
                waypoints = RetracePath(startNode, targetNode).ToArray();
            }
            OnComplete(waypoints, pathSuccess);
            yield break;
        }

        private static Vector3[] RetracePath(Node startNode, Node endNode)
        {
            List<Node> path = new List<Node>();
            Node currentNode = endNode;

            while (currentNode != startNode)
            {
                path.Add(currentNode);
                currentNode = currentNode.parent;
            }
            Vector3[] waypoints = SimplifyPath(path);
            Array.Reverse(waypoints);
            return waypoints;
        }

        private static Vector3[] SimplifyPath(List<Node> path)
        {
            List<Vector3> waypoints = new List<Vector3>();
            Vector2 lastNodeDirection = Vector2.zero;
            for(int i = 1; i < path.Count; i++)
            {
                waypoints.Add(path[i].worldPosition);
                Vector2 newNodeDirection = new Vector2(path[i - 1].gridX - path[i].gridX, path[i - 1].gridY - path[i].gridY);
                if(newNodeDirection != lastNodeDirection)
                {
                    waypoints.Add(path[i].worldPosition);
                }
                lastNodeDirection = newNodeDirection;
            }

            return waypoints.ToArray();
        }

        private static int GetDistance(Node from, Node to)
        {
            int distanceX = Mathf.Abs(from.gridX - to.gridX);
            int distanceY = Mathf.Abs(from.gridY - to.gridY);

            if(distanceX > distanceY)
            {
                return 14 * distanceY + 10 * (distanceX - distanceY);
            }
            return 14 * distanceY + 10 * (distanceY - distanceX);
        }
    }
}