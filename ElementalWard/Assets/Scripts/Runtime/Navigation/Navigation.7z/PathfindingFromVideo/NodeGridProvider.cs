using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ElementalWard.Pathfinding
{
    public class NodeGridProvider : MonoBehaviour
    {
        public bool displayGridGizmos;
        public Vector2 gridWorldSize;
        public float nodeRadius;

        private Node[,] grid;
        private float nodeDiameter;
        private int gridSizeX;
        private int gridSizeY;
        public int MaxSize
        {
            get
            {
                return gridSizeX * gridSizeY;
            }
        }

        private void Start()
        {
            nodeDiameter = nodeRadius * 2;
            gridSizeX = Mathf.RoundToInt(gridWorldSize.x / nodeDiameter);
            gridSizeY = Mathf.RoundToInt(gridWorldSize.y / nodeDiameter);
            CreateGrid();
        }

        public List<Node> GetNeighbouringNodes(Node node)
        {
            List<Node> result = new List<Node>();

            for(int x = -1; x <= 1; x++)
            {
                for(int y = -1; y <= 1; y++)
                {
                    //This is the node specified in the parameter
                    if (x == 0 && y == 0)
                        continue;

                    int checkX = node.gridX + x;
                    int checkY = node.gridY + y;

                    if(checkX >= 0 && checkX < gridSizeX && checkY >= 0 && checkY < gridSizeY)
                    {
                        result.Add(grid[checkX, checkY]);
                    }
                }
            }
            return result;
        }

        public Node GetNodeFromWorldPosition(Vector3 worldPos)
        {
            float percentX = (worldPos.x + gridWorldSize.x / 2) / gridWorldSize.x;
            float percentY = (worldPos.z + gridWorldSize.y / 2) / gridWorldSize.y;
            
            percentX = Mathf.Clamp01(percentX);
            percentY = Mathf.Clamp01(percentY);

            int x = Mathf.RoundToInt((gridSizeX - 1) * percentX);
            int y = Mathf.RoundToInt((gridSizeY - 1) * percentY);

            return grid[x, y];
        }
        private void CreateGrid()
        {
            grid = new Node[gridSizeX, gridSizeY];
            Vector3 worldBottomLeft = transform.position - Vector3.right * gridWorldSize.x/2 - Vector3.forward * gridWorldSize.y/2;
            for(int x = 0; x < gridSizeX; x++)
            {
                for (int y = 0; y < gridSizeY; y++)
                {
                    Vector3 worldPoint = worldBottomLeft + Vector3.right * (x * nodeDiameter + nodeRadius) + Vector3.forward * (y * nodeDiameter + nodeRadius);
                    bool open = true;
                    int penalty = 0;
                    
                    Ray ray = new Ray(worldPoint + Vector3.up, Vector3.down);
                    RaycastHit[] hits;

                    hits = Physics.SphereCastAll(ray, nodeRadius, 1024, LayerIndex.world.Mask);
                    foreach(var hit in hits)
                    {
                        if(hit.collider.TryGetComponent<PathfindingModifier>(out var modifier))
                        {
                            open = !modifier.isObstacle;
                            penalty = modifier.penaltyCost;
                            break;
                        }
                    }

                    grid[x, y] = new Node
                    {
                        open = open,
                        movementPenalty = penalty,
                        worldPosition = worldPoint,
                        gridX = x,
                        gridY = y,
                        gCost = 0,
                        hCost = 0
                    };
                }
            }
            BlurPenaltyMap(3);
        }

        private void BlurPenaltyMap(int blurSize)
        {
            int kernelSize = blurSize * 2 + 1;
            int kernelExtents = (kernelSize - 1) / 2;

            int[,] penaltiesHorizontalPass = new int[gridSizeX, gridSizeY];
            int[,] penaltiesVerticalPass = new int[gridSizeX, gridSizeY];

            for(int y = 0; y < gridSizeY; y++)
            {
                for(int x = -kernelExtents; x <= kernelExtents; x++)
                {
                    int sampleX = Mathf.Clamp(x, 0, kernelExtents);
                    penaltiesHorizontalPass[0, y] += grid[sampleX, y].movementPenalty;
                }

                for(int x = 1; x < gridSizeX; x++)
                {
                    int removeIndex = x - kernelExtents - 1;
                    int addIndex = x + kernelExtents;
                    removeIndex = Mathf.Clamp(removeIndex, 0, gridSizeX);
                    addIndex = Mathf.Clamp(addIndex, 0, gridSizeX - 1);

                    penaltiesHorizontalPass[x, y] = penaltiesHorizontalPass[x-1, y] - grid[removeIndex, y].movementPenalty + grid[addIndex, y].movementPenalty;
                }
            }

            for (int x = 0; x < gridSizeX; x++)
            {
                for (int y = -kernelExtents; y <= kernelExtents; y++)
                {
                    int sampleY = Mathf.Clamp(y, 0, kernelExtents);
                    penaltiesVerticalPass[x, 0] += penaltiesHorizontalPass[x, sampleY];
                }

                for (int y = 1; y < gridSizeX; y++)
                {
                    int removeIndex = y - kernelExtents - 1;
                    int addIndex = y + kernelExtents;
                    removeIndex = Mathf.Clamp(removeIndex, 0, gridSizeY);
                    addIndex = Mathf.Clamp(addIndex, 0, gridSizeY - 1);

                    penaltiesVerticalPass[x, y] = penaltiesVerticalPass[x, y-1] - penaltiesHorizontalPass[x, removeIndex] + penaltiesHorizontalPass[x, addIndex];

                    int blurredPenalty = Mathf.RoundToInt((float)penaltiesVerticalPass[x, y] / (kernelSize * kernelSize));
                    grid[x, y].movementPenalty = blurredPenalty;
                }
            }
        }

        void OnDrawGizmos()
        {
            Gizmos.DrawWireCube(transform.position, new Vector3(gridWorldSize.x, 1, gridWorldSize.y));
            if (grid != null && displayGridGizmos)
            {
                foreach (Node n in grid)
                {

                    Gizmos.color = Color.white;
                    Gizmos.color = (n.open) ? Gizmos.color : Color.red;
                    Gizmos.DrawCube(n.worldPosition, Vector3.one * (nodeDiameter));
                }
            }
        }
    }
}
