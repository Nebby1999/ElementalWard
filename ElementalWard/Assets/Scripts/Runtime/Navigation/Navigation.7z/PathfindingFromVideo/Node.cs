using Nebula;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ElementalWard.Pathfinding
{
    public class Node : Heap<Node>.IHeapItem<Node>
    {
        public bool open;
        public Vector3 worldPosition;
        public Node parent;
        public int movementPenalty;

        public int gCost;
        public int hCost;
        public int FCost => gCost + hCost;

        public int HeapIndex { get => _heapIndex; set => _heapIndex = value; }
        private int _heapIndex;

        public int gridX;
        public int gridY;

        public int CompareTo(Node other)
        {
            int compare = FCost.CompareTo(other.FCost);
            if (compare == 0)
            {
                compare = hCost.CompareTo(other.hCost);
            }
            return -compare;
        }
    }
}
