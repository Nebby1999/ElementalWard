using System;
using System.Collections.Generic;
using System.Linq;
using Unity.Mathematics;
using UnityEngine;

namespace Nebula.Navigation
{
    /// <summary>
    /// Represents a graph of nodes on a scene, can also add and remove nodes from its nodeGraphAsset
    /// </summary>
    public class NodeGraphProvider : MonoBehaviour, IGraphProvider
    { 
        public INodeGraph NodeGraph => _graphAsset;
        [SerializeField] private NodeGraphAsset _graphAsset;


        public void AddNewNode(Vector3 position)
        {
            if (NodeGraph == null)
                return;

                position += NodeGraph.NodeOffset;

            var serializedNode = new SerializedPathNode
            {
                worldPosition = position,
            };

            NodeGraph.SerializedNodes.Add(serializedNode);
        }

        public void Bake()
        {
            if (NodeGraph == null)
                return;

            var baker = NodeGraph.GetBaker();
            baker.BakeNodes();
            baker.CommitBakedNodes();
        }

        public void Clear()
        {
            NodeGraph?.ClearSerializedNodesAndLinks();
        }

        public RuntimePathNodeLink[] GetRuntimePathNodeLinks()
        {
            return NodeGraph?.RuntimeLinks ?? Array.Empty<RuntimePathNodeLink>();
        }

        public RuntimePathNode[] GetRuntimePathNodes()
        {
            return NodeGraph?.RuntimeNodes ?? Array.Empty<RuntimePathNode>();
        }

        public List<SerializedPathNodeLink> GetSerializedPathLinks()
        {
            return NodeGraph?.SerializedLinks ?? new List<SerializedPathNodeLink>();
        }

        public List<SerializedPathNode> GetSerializedPathNodes()
        {
            return NodeGraph?.SerializedNodes ?? new List<SerializedPathNode>();
        }

        public void RemoveNearestNode(Vector3 position)
        {
            if (NodeGraph == null)
                return;

            var nodes = GetSerializedPathNodes();
            int nearest = -1;
            float nearestDistance = float.MaxValue;
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                var dist = Vector3.Distance(node.worldPosition, position);
                if (dist < nearestDistance)
                {
                    nearest = i;
                    nearestDistance = dist;
                }
            }

            if (nearest != -1)
            {
                var node = nodes[nearest];

                nodes.RemoveAt(nearest);
                if (node.serializedPathNodeLinkIndices.Count > 0)
                    NodeGraph.ClearSerializedLinks();
            }
        }
    }
}